package com.encapsulearn.OnlineQuiz_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineQuizSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineQuizSpringApplication.class, args);
	}

}
